class ImageConstant {
  static String imagePath = 'assets/reports_assets/images';
  static String imgChartUp = '$imagePath/img_arrow_up_condition.svg';
  static String imgChartDown = '$imagePath/img_arrow_down_condition.svg';
  static String imgLogo = '$imagePath/img_logo.svg';
  static String imgApple = '$imagePath/img_apple.svg';
  static String imgMCD = '$imagePath/img_mcd.svg';
  static String imgBack = '$imagePath/img_back.png';
}
