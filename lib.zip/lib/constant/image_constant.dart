class ImageConstant {
  static const String cart_logo = 'assets/images/logo.png';
  static const String ilus_forgot_pass = 'assets/images/ilus_forgot_pass.jpg';
}
