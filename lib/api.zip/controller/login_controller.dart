
import 'package:get/get.dart';

class LoginController extends GetxController{
  RxBool showPass = false.obs;
}