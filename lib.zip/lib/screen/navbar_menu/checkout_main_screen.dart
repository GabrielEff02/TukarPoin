import 'dart:math';

import 'package:e_commerce/screen/gabriel/core/app_export.dart';
import 'package:e_commerce/screen/gabriel/notifications/item_screen.dart';

import 'package:get/get.dart';

import 'dart:async';
import 'dart:convert';
import 'package:http/http.dart' as http;

class CheckoutMainScreen extends StatefulWidget {
  const CheckoutMainScreen({super.key});

  @override
  State<CheckoutMainScreen> createState() => _CheckoutMainScreenState();
}

class _CheckoutMainScreenState extends State<CheckoutMainScreen> {
  static List<dynamic> productData = [];
  String selectedCompanyCode = 'semua';

  @override
  void initState() {
    super.initState();
    getProductData();
    localDataCheck();
  }

  Future<List<Map<String, dynamic>>> getCompan() async {
    try {
      final response =
          await http.get(Uri.parse('${API.BASE_URL}/get_compan.php'));

      if (response.statusCode == 200) {
        // Mengonversi JSON response menjadi List<Map<String, dynamic>>
        List<dynamic> jsonData = json.decode(response.body);
        return jsonData.map((outlet) {
          return {'compan_code': outlet['compan_code'], 'name': outlet['name']};
        }).toList();
      } else {
        throw Exception('Failed to load data');
      }
    } catch (e) {
      throw Exception('Failed to load data: $e');
    }
  }

  Future<void> getProductData() async {
    String compan_code = 'all';

    if (await LocalData.containsKey('compan_code')) {
      compan_code = await LocalData.getData('compan_code');
    }
    final fetchData = await CheckoutsData.getInitData(compan_code);

    setState(() {
      productData = fetchData['productData'].toList();
    });
  }

  void localDataCheck() async {
    if (await LocalData.containsKey('compan_code')) {
      final compan_code = await LocalData.getData('compan_code');
      setState(() {
        selectedCompanyCode = compan_code;
      });
    }
    print(await LocalData.getData('cart'));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: WidgetHelper.appbarWidget(() {
        Get.back();
      }, Text('Redeem'), actions: [
        FutureBuilder<List<Map<String, dynamic>>>(
          future: getCompan(),
          builder: (context, snapshot) {
            if (snapshot.connectionState == ConnectionState.waiting) {
              return CircularProgressIndicator(); // Tampilkan loading saat fetch data
            } else if (snapshot.hasError) {
              return Text("Error: ${snapshot.error}");
            } else if (!snapshot.hasData || snapshot.data!.isEmpty) {
              return Text("Tidak ada data perusahaan");
            }

            List<Map<String, dynamic>> companies = [
              {'compan_code': 'semua', 'name': 'Semua'}
            ];
            companies.addAll(snapshot.data!);
            return DropdownButton<String>(
              hint: Text("Pilih Perusahaan"),
              value: selectedCompanyCode,
              items: companies.map((company) {
                return DropdownMenuItem<String>(
                  value: company["compan_code"], // Menyimpan company_code
                  child: Text(company["name"]!), // Menampilkan name
                );
              }).toList(),
              onChanged: (String? newValue) {
                setState(() {
                  selectedCompanyCode = newValue!;
                });
                LocalData.saveData('compan_code', selectedCompanyCode);
                getProductData();
              },
            );
          },
        ),
      ]),
      body: SingleChildScrollView(
        child: Column(
          children: productRow(productData),
        ),
      ),
    );
  }

  List<Widget> productRow(List productData) {
    List<Widget> rows = [];

    for (int i = 0; i < productData.length; i += 2) {
      rows.add(
        Container(
          margin: const EdgeInsets.symmetric(horizontal: 10),
          padding: const EdgeInsets.symmetric(vertical: 8.0),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Expanded(
                child: _buildProductCard(context, productData[i]),
              ),
              if (i + 1 < productData.length) SizedBox(width: 16),
              if (i + 1 < productData.length)
                Expanded(
                  child: _buildProductCard(context, productData[i + 1]),
                )
              else
                SizedBox(width: 16),
            ],
          ),
        ),
      );
    }

    return rows;
  }

  Widget _buildProductCard(BuildContext context, Map<String, dynamic> product) {
    return Container(
      height: 300,
      padding: EdgeInsets.all(16.0),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12.0),
        boxShadow: [
          BoxShadow(
            color: Colors.black26,
            blurRadius: 8.0,
            offset: Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          GestureDetector(
            onTap: () {
              Get.to(ItemScreen(data: product.map((key, value) {
                return MapEntry(key, value.toString());
              })));
            },
            child: CustomImageView(
              imagePath: "${API.BASE_URL}/images/${product['image_url']}",
              height: 150, // Adjust image height as needed
              width: double.infinity,
              alignment: Alignment.center,
            ),
          ),
          SizedBox(height: 12), // Space between image and text
          Text(
            maxLines: 2,
            product['product_name'], // Product name
            style: TextStyle(
              fontWeight: FontWeight.bold,
              fontSize: 18, // Increase font size
              color: Colors.black87, // Darker text color
            ),
          ),
          SizedBox(height: 4), // Space between name and price
          Text(
            'Point: ${product['price']}', // Product price
            style: TextStyle(
              fontSize: 16, // Font size for price
              color: Colors.green, // Green color for price
            ),
          ),
          SizedBox(height: 4), // Space between price and quantity
          Text(
            'Quantity: ${product['quantity']}', // Product quantity
            style: TextStyle(
              fontSize: 14, // Font size for quantity
              color: Colors.grey[600], // Grey color for quantity
            ),
          ),
        ],
      ),
    );
  }
}
